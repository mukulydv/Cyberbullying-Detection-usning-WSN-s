clc
clear all
close all
clc

run('Simulation_WSN.m');



 